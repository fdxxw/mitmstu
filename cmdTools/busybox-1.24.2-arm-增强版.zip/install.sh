#!/system/bin/sh
#busybox安装脚本
#版本0.1
#天朝刁民
#2015.10.10
echo
echo "开始安装busybox!....."
for i in $(/system/xbin/busybox --list)
do
ln -s /system/xbin/busybox /system/xbin/$i
done
echo "安装完成！"

